//
//  FirstViewController.swift
//  Appearance
//
//  Created by Tobioka on 2017/10/13.
//  Copyright © 2017年 tnantoka. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    /// [marker1]
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let picker = UIImagePickerController()
        picker.sourceType = .photoLibrary
        present(picker, animated: true, completion: nil)
    }
    /// [marker1]
    */
}

