//
//  Person.swift
//  RealmExample
//
//  Created by Tobioka on 2017/10/15.
//  Copyright © 2017年 tnantoka. All rights reserved.
//

/// [marker1]
import Foundation
import RealmSwift

class Person: Object {
    @objc dynamic var name = ""
}
/// [marker1]
