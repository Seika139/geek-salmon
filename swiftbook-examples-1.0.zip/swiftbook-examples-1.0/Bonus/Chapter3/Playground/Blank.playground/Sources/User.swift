import Foundation

public class User {
    public let name: String

    public init(name: String) {
        self.name = name
    }
}
